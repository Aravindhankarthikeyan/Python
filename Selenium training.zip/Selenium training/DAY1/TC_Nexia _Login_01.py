from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
import pytest

class Test_Nexia_Login:

    @pytest.fixture()#-This will excute for every TEST'S:
    def setup(self):
        serv_Obj = Service("C:\\driver\\chromedriver-win64\\chromedriver.exe")
        self.driver = webdriver.Chrome(service=serv_Obj)
        self.driver.get("https://qa-diagnostics.tranehome.com")
        self.driver.maximize_window()
        self.driver.implicitly_wait(10)
        yield
        self.driver.close()
    def test_Title(self,setup):
        var = self.driver.title == "Trane® Diagnostics"
    def test_Login(self,setup):
        self.driver.find_element(By.ID, "signInName").send_keys("nexiadealer")

        self.driver.find_element(By.NAME, "Password").send_keys("CookieS2020!@#")


