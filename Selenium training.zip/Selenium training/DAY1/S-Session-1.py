import time

from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By

serv_Obj=Service("C:\\driver\\chromedriver-win64\\chromedriver.exe")
driver=webdriver.Chrome(service=serv_Obj)
driver.get("https://qa-diagnostics.tranehome.com")
driver.maximize_window()
driver.implicitly_wait(10)
#In-Built Locators:
driver.find_element(By.ID,"signInName").send_keys("nexiadealer")

driver.find_element(By.NAME,"Password").send_keys("CookieS2020!@#")

driver.find_element(By.ID,"next").click()


#CSS Selectors:
"""
driver.find_element(By.CSS_SELECTOR,"#signInName").send_keys("nexiadealer")
time.sleep(5)
driver.find_element(By.CSS_SELECTOR,"input[autocomplete=current-password]").send_keys("CookieS2020!@#")
time.sleep(5)
driver.find_element(By.CSS_SELECTOR,"button[id=next]").click()
time.sleep(5)
driver.find_element(By.CSS_SELECTOR,"input.sc-egkSDF").send_keys("2222K5002X")           
time.sleep(10)                                                                           
"""
#X-PATH:
driver.find_element(By.XPATH,'//input[@placeholder="Search"]').clear()
driver.find_element(By.XPATH,'//input[@placeholder="Search"]').send_keys("")



