import time

from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
serv_obj = Service("C:\driver\chromedriver_win32\chromedriver.exe")
driver = webdriver.Chrome(service=serv_obj)
driver.get("https://demo.nopcommerce.com/#")
driver.maximize_window()
def Relative_Xpath():
    driver.find_element(By.XPATH,"//*[@class='ico-login']").click()
    time.sleep(2)
    #driver.close()
Relative_Xpath()
def Abs_Xpath():
    driver.find_element(By.XPATH,"/html/body/div[6]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a").click()
    time.sleep(5)
    driver.close()
Abs_Xpath()
def Relative_OR():
    driver.find_element(By.XPATH,"//*[@class='email'or@data-val='true']").send_keys("aravind")
    time.sleep(2)
Relative_OR()
def Relative_and():
    driver.find_element(By.XPATH,"//*[@class='password'and@id='Password']").send_keys("aravind")
    time.sleep(2)
    driver.close()
Relative_and()
def Relative_Contains():
    driver.find_element(By.XPATH,"//*[contains(@type,'bu')]").click()
    time.sleep(2)
    driver.close()
Relative_Contains()
def Relative_Starts_with():
    driver.find_element(By.XPATH,"//*[starts-with(@type,'ra')]").click()
    time.sleep(2)
    driver.close()
Relative_Starts_with()
def Text():
    driver.find_element(By.XPATH,"//a[text()='Facebook']").click()
Text()

