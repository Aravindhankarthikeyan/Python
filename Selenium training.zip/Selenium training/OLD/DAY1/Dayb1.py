import time
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
serv_obj = Service("C:\Aravind\PycharmProjects\pythonProject\driver\chromedriver-win64\chromedriver.exe")
driver = webdriver.Chrome(service=serv_obj)
driver.get("https://qa.nexiadev.com/login")
time.sleep(2)
driver.maximize_window()
time.sleep(2)
driver.execute_script("window.scrollTo(0,400)")
driver.find_element(By.XPATH, "//*[@alt='iTunes Store']").click()
time.sleep(2)
driver.close()
