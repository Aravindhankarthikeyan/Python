import time

from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
serv_obj = Service("C:\driver\chrome-win32\chrome-win32\chrome_proxy.exe")
time.sleep(2)
driver = webdriver.Chrome(service=serv_obj)
time.sleep(2)
driver.get("https://www.saucedemo.com/")
driver.find_element(By.ID, "user-name").send_keys("standard_user")
driver.find_element(By.ID, "password").send_keys("secret_sauce")
driver.find_element(By.ID, "login-button").click()
#1.Link text used for links(Built links in URL)
def a():
    driver.find_element(By.LINK_TEXT, "Twitter").click()  # Link text used for links
    driver.find_element(By.PARTIAL_LINK_TEXT, "aceboo").click()
#a()
#2.Class_name(sliders)/(Find more element)/(In a single in all class name are same means use this)
def b():
    sliders=driver.find_element(By.CLASS_NAME,"inventory_item_label").click()
    time.sleep(3)
    driver.close()
#b()
import time
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
serv_obj = Service("C:\driver\chromedriver_win32\chromedriver.exe")
driver = webdriver.Chrome(service=serv_obj)
driver.get("https://demo.nopcommerce.com/")
def A():
    #1.Link text used for links(Built links in URL)
    driver.find_element(By.LINK_TEXT,"2").click()
    #2.Class_name(sliders)/(Find more element)
    # /(In a single in all class name are same means use this)
    # /Group of slider is there means we find the len of tha
    a=driver.find_element(By.CLASS_NAME,"news-title").click()
    time.sleep(5)
    driver.close()
    #3.Tag name(For find total number of links in webpage)
    driver.find_element(By.TAG_NAME,'a')
    driver.close()
A()





