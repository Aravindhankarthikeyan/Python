###1.Customized selectors:
#1.Css Selectors
#2.X PATH

#1.CSS Selectors:(css and xpath not find in HTML)
'TAG & ID'
'TAG & CLASS'
"TAG & Attribute"
"Tag class and Attribute"
'''THESE ARE THE COMBINATION'''
"""TAG NAME IS OPTIONAL"""
#1.TAG & ID:
"""SYNTAX:TAG#VALUE """
import time
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
serv_obj=Service("C:\driver\chromedriver_win32\chromedriver.exe")
driver=webdriver.Chrome(service=serv_obj)
driver.get("https://demo.nopcommerce.com/#")
driver.maximize_window()
def TAG_ID():#
    #driver.find_element(By.CSS_SELECTOR,"input#small-searchterms").send_keys("NIKE")
    driver.find_element(By.CSS_SELECTOR,"#small-searchterms").send_keys("NIKE")
    time.sleep(4)
    #driver.close()
    print("TAG ID FINISHED")
TAG_ID()
#2.TAG & CLASS:
"""SYNTAX:TAG.VALUE """
def TAG_CLASS():
    #driver.find_element(By.CSS_SELECTOR,"button.button-1").click()
    driver.find_element(By.CSS_SELECTOR,".button-1").click()
    time.sleep(3)
    #driver.close()
    print("TAG & CLASS FINISHED")
TAG_CLASS()
#3.TAG & ATTRIBUTE;
"""SYNTAX:TAG[Attribute=value]"""
def TAG_Attribute():
    driver.find_element(By.CSS_SELECTOR,"select[id=products-orderby]").click()
    time.sleep(5)
    #driver.close()
    print("TAG & Attribute FINISHED")
TAG_Attribute()
#4.TAG_CLASS_ATTRIBUTE:
"""SAME VALUE OF CLASS,ID,ETC ATTRIBUTE ON THAT TIME WE USE THIS"""
"""SYNTAX:TAG.Valueofclass[Attribute=value]"""
driver.find_element(By.LINK_TEXT,"Nike Floral Roshe Customized Running Shoes").click()
#MY T#driver.find_element("select[name=product_attribute_6]").click()
def TAG_class_Attribute():
    driver.find_element(By.CSS_SELECTOR,"button.button-1[id=add-to-cart-button-24]").click()
    time.sleep(5)
    driver.close()
    print("TAG&class& Attribute FINISHED")
TAG_class_Attribute()






